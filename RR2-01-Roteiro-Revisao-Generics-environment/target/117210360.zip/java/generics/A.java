package generics;

public interface A<T> {
	
	public void m(T value);

}
