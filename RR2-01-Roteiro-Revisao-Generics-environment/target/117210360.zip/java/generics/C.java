package generics;

public class C<T> implements A<T> {

   @Override
   public void m(T value) {
      // TODO Auto-generated method stub

   }
   //	
   //	public void a(Collection<T> obj) {
   //		
   //	}
   //	
   //	public void x(?  T obj) {
   //		
   //	}

}
