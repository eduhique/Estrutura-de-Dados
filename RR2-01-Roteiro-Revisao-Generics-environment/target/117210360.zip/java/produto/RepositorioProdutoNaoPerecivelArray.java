package produto;


public class RepositorioProdutoNaoPerecivelArray extends RepositorioProdutosArray<ProdutoNaoPerecivel> {

	public RepositorioProdutoNaoPerecivelArray(int size) {
		super(size);
	}
}
